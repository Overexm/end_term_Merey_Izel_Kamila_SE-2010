package com.company.end;
import java.util.ArrayList;
import java.util.Scanner;

public class Bankomat implements Service//implementing Service intervace
{
    DBManager dbManager = new DBManager();//object
    User currentUser;


    static Scanner in = new Scanner(System.in);

    public void registerClient()//client register
    {

        System.out.print("1.Enter your name:");
        String name = in.next();
        System.out.print("2.Enter your surname:");
        String surname = in.next();
        System.out.print("3.Enter your username:");
        String username = in.next();
        while (!(dbManager.checkUsernameToRegister(username))){
            System.out.println("This username is already exists, type again!");
            System.out.print("Enter your username:");
            username = in.next();//outputing the choices
        }
        System.out.print("4.Enter your password:");
        String password = in.next();
        Client client = new Client(null, name,surname,username,password);
        boolean check = dbManager.register(client);
        if(check){
            System.out.println("Successfully registered!");//if the user is registeres the sentence will appear
        }else {
            System.out.println("Incorrect date!");// else will be this sentence
        }

    }

    public void loginClient()//login create method
    {
        System.out.print("Enter username: ");
        String username = in.next();
        System.out.print("Enter password: ");
        String password = in.next();
        if(dbManager.loginClient(username,password)!=null){
            currentUser = dbManager.loginClient(username,password);
            homePage();
        }
    }

    public void myProfilePage(){
        System.out.println("Name: " + currentUser.getName());
        System.out.println("Surname: " + currentUser.getSurname());
        System.out.println("Username: " + currentUser.getUsername());
        System.out.println("Password: " + currentUser.getPassword());
        System.out.println("0.BACK");
        int c = in.nextInt();//there will be listed your registrated info
    }

    @Override
    public void addMoney(){
        ArrayList<Wallet> wallets = dbManager.getWalletsByClientId(currentUser.getId());//for adding money
        int count = 1;
        if(wallets.size()>0) {
            ArrayList<Long> walletIds = new ArrayList<>();
            System.out.println("Select your wallet:");
            for (Wallet w : wallets) {
                System.out.println(count + "." + w.getName());
                walletIds.add(w.getId());
                count++;
            }
            System.out.print("Choose:");
            Long choose = in.nextLong();
            if (choose <= wallets.size()) {
                System.out.println("How much money do u wanna add?");
                System.out.print("Money:");
                double money = in.nextDouble();
                Long wallet_id = null;
                for(int i=0;i<walletIds.size();i++){
                    if(i==choose-1){
                        wallet_id = walletIds.get(i);
                    }
                }
                boolean check = dbManager.addMoneyToClientsWallet(money, wallet_id, currentUser);
                if (check) {
                    System.out.println("Successfully added!");
                } else {
                    System.out.println("Couldn't add money");
                }
            }
        }else {
            System.out.println("Create wallet.");
            System.out.print("Enter currency name:");
            String currency = in.next();
            dbManager.addWallet(new Wallet(null,currency,0), (Client)currentUser);
        }
    }

    @Override
    public void withdrawCash(){
        ArrayList<Wallet> wallets = dbManager.getWalletsByClientId(currentUser.getId());// for take off the money
        int count = 1;
        if(wallets.size()>0) // if the user has a wallet this statement will work
        {
            ArrayList<Long> walletIds = new ArrayList<>();
            System.out.println("Select your wallet:");
            for (Wallet w : wallets) {
                System.out.println(count + "." + w.getName());
                walletIds.add(w.getId());
                count++;
            }
            System.out.print("Choose:");
            Long choose = in.nextLong();
            if (choose <= wallets.size()) {
                System.out.println("How much money do u wanna withdraw?");
                System.out.print("Money:");
                double money = in.nextDouble();
                Long wallet_id = null;
                for(int i=0;i<walletIds.size();i++){
                    if(i==choose-1){
                        wallet_id = walletIds.get(i);
                    }
                }

                boolean check = dbManager.withdrawCashToClients(money, wallet_id, currentUser);
                if (check) {
                    System.out.println("Successfully withdrawed!");
                } else {
                    System.out.println("You haven't enough money to withdraw");
                }
            }
        }else //otherwise the user must create a wallet
            {
            System.out.println("Create wallet.");
            System.out.print("Enter currency name:");
            String currency = in.next();
            dbManager.addWallet(new Wallet(null,currency,0), (Client)currentUser);
        }
    }

    public void myWallets()//there the user can check their wallets
    {
        ArrayList<Wallet> wallets = dbManager.getWalletsByClientId(currentUser.getId());
        int count = 1;
        if(wallets.size()>0) {
            for (Wallet w : wallets) {
                System.out.println(count + "." + w.getName() + ", Cash: " + w.getCash());
                count++;
            }
        }else//if it's not exists they must create a wallet
            {
            System.out.println("Create wallet.");
            System.out.print("Enter currency name:");
            String currency = in.next();
            dbManager.addWallet(new Wallet(null,currency,0), (Client)currentUser);
        }
        System.out.println("0.Back");
        String c = in.next();
    }

    public void homePage()//this is homepage
    {
        while (true) {
            System.out.println("1.My Profile");
            System.out.println("2.Add Money");
            System.out.println("3.Withdraw cash");
            System.out.println("4.My Wallets");
            System.out.println("5.Create new wallet");
            System.out.println("0.Logout");
            int c = in.nextInt();
            if (c == 0) {
                currentUser = null;
                return;
            } else if (c == 1) {
                myProfilePage();
            } else if (c == 2) {
                addMoney();
            } else if (c == 3) {
                withdrawCash();
            } else if (c == 4) {
                myWallets();
            }else if(c==5){
                createNewWallet();
            }
        }
    }

    public void createNewWallet()//there the user can create new wallet
    {
        System.out.println("Create wallet.");
        System.out.print("Enter currency name:");
        String currency = in.next();
        dbManager.addWallet(new Wallet(null,currency,0), (Client)currentUser);
    }

    public void chanceToClient()//there we check for their chance
    {
        System.out.println("How much money do you wanna get to Credit?");
        System.out.print("Enter sum:");
        double sum = in.nextDouble();
        System.out.println("How many month do you wanna get?");
        System.out.print("Enter sum:");
        int month = in.nextInt();
        System.out.println("Enter your salary to check your chance to get Credit");
        System.out.print("Salary: ");
        double salary = in.nextDouble();
        double percent;
        // 500000/10 = 50000  == 250000/12
        percent = sum+ (sum*0.1);
        if(percent/month <= salary/2) {
            System.out.println("You need to pay " + percent/month + " every month!");

        }else {
            System.out.println("You have no chance to get Credit!");
        }

    }


    public Bankomat()//the menu option
    {
        int c;
        while (true){
            System.out.println("1.Login");
            System.out.println("2.Register");
            System.out.println("3.Chance to Credit");
            c = in.nextInt();
            if(c==0){
                break;
            }else if(c==1){

                loginClient();

            }else if(c==2){

                registerClient();

            }else if(c==3){
                chanceToClient();
            }
        }
    }
}
