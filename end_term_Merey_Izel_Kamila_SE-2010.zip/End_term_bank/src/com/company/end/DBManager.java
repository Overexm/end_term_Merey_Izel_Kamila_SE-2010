package com.company.end;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;

public class DBManager {

    Connection connection;

    public DBManager() {
        try {

            Class.forName("org.postgresql.Driver");

            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/merey_end_java", "postgres", "1234567" );
        }catch (Exception e){
            e.printStackTrace();//connection with JDBC or postgresql
        }
    }




    public boolean checkUsernameToRegister(String username)//checks username for register
    {
        ArrayList<Client> allClients = getAllClients();
        for(Client c:allClients){
            if(c.getUsername().equals(username)){
                return false;
            }
        }
        return true;
    }

    public boolean register(User user){
        ArrayList<Client> allClients = getAllClients();
        for(Client c:allClients){
            if(c.getUsername().equals(user.getUsername())){
                return false;
            }
        }
        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO clients (name,surname,username,password)" +
                    "VALUES(?,?,?,?)");

            statement.setString(1,user.getName());
            statement.setString(2,user.getSurname());
            statement.setString(3,user.getUsername());
            statement.setString(4,user.getPassword());
            statement.executeUpdate();
            statement.close();
            return true;

        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public void createCheck(Check check){
        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO clients_checks (client_id,wallet_id,date,text)" +
                    "VALUES(?,?,?,?)");

            statement.setLong(1,check.getClient().getId());
            statement.setLong(2,check.getWallet().getId());
            statement.setDate(3,check.getDate());
            statement.setString(4,check.getText());
            statement.executeUpdate();
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public ArrayList<Wallet> getWalletsByClientId(Long id){
        ArrayList<Wallet> allWallets = getAllWallets();
        ArrayList<Wallet> userWallets = new ArrayList<>();
        ArrayList<ClientsWallet> clientsWallets = getAllClientsWallets();
        for(ClientsWallet w: clientsWallets){
            if(w.getClient_id().equals(id)){
                userWallets.add(getWalletById(w.getWallet_id()));
            }

        }

        return userWallets;
    }


    public Wallet getWalletById(Long idshka){
        Wallet wallet = null;
        String asd;
        try{

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT id, name, cash FROM wallets WHERE id="+idshka + "");

            ResultSet resultSet = statement.executeQuery();


            while (resultSet.next()){

                wallet = new Wallet(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("cash")

                );
            }
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        return wallet;
    }

    public Client getClientByID(Long idshka){
        Client client = null;
        String asd;
        try{

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT id, name, surname, username, password FROM clients WHERE id="+idshka + "");

            ResultSet resultSet = statement.executeQuery();


            while (resultSet.next()){

                client = new Client(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getString("surname"),
                        resultSet.getString("username"),
                        resultSet.getString("password")

                );
            }
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        return client;
    }

    public Check getCheckByClientId(Long idshka){
        Check check = null;
        OperationChecks operationChecks = null;
        try{

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT id, client_id, wallet_id, date, text  FROM clients_checks WHERE client_id="+idshka + "");

            ResultSet resultSet = statement.executeQuery();


            while (resultSet.next()){

                check = new Check(
                        resultSet.getLong("id"),
                        getWalletById(resultSet.getLong("wallet_id")),
                        resultSet.getDate("date"),
                        getClientByID(resultSet.getLong("client_id")),
                        resultSet.getString("text")

                );
            }
            statement.close();


        }catch (Exception e){
            e.printStackTrace();
        }

        return check;
    }

    public boolean addMoneyToClientsWallet(double money, Long wallet_id, User currentUser){
        Wallet wallet = getWalletById(wallet_id);
        double addingMoney = money;

        if(wallet!=null){
            try {
                money = money + wallet.getCash();
                PreparedStatement ps = connection.prepareStatement("UPDATE wallets SET cash =? WHERE id =?");
                ps.setDouble(1, money);
                ps.setLong(2, wallet.getId());
                ps.executeUpdate();
                ps.close();

                // CHECK

                String typeOfCheck = "Type of operation Add Money, ";
                java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
                String text = typeOfCheck + " added:" + addingMoney;

                createCheck(new Check(null,wallet,date,(Client)currentUser,text));
                Check check = getCheckByClientId(currentUser.getId());
                CheckForOperations(currentUser,check);
                // END CHECK

                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return false;
    }

    public boolean withdrawCashToClients(double money, Long wallet_id, User currentUser){
        Wallet wallet = getWalletById(wallet_id);
        double withdrawingmoney = money;

        if(wallet!=null) {
            if (wallet.getCash() > money) {
                try {
                    money = wallet.getCash() - money;
                    PreparedStatement ps = connection.prepareStatement("UPDATE wallets SET cash =? WHERE id =?");
                    ps.setDouble(1, money);
                    ps.setLong(2, wallet.getId());
                    ps.executeUpdate();
                    ps.close();

                    // CHECK

                    String typeOfCheck = "Type of operation Withdraw Money, ";
                    java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
                    String text = typeOfCheck + " withdrawed:" + withdrawingmoney;

                    createCheck(new Check(null, wallet, date, (Client) currentUser, text));
                    Check check = getCheckByClientId(currentUser.getId());
                    CheckForOperations(currentUser, check);
                    // END CHECK

                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }else {
            System.out.println("YOU HAVEN'T ENOUGH MONEY TO WITHDRAW!");
            return false;
        }
        return false;
    }

    public ArrayList<ClientsWallet> getAllClientsWallets(){
        ArrayList<ClientsWallet> clientsWallets = new ArrayList<>();
        try{

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT id, client_id, wallet_id FROM clients_wallets");

            ResultSet resultSet = statement.executeQuery();


            while (resultSet.next()){

                clientsWallets.add(new ClientsWallet(
                        resultSet.getLong("id"),
                        resultSet.getLong("client_id"),
                        resultSet.getLong("wallet_id")

                ));
            }
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        return clientsWallets;
    }

    public Client loginClient(String username, String password){
        ArrayList<Client> clients = getAllClients();
        for(Client c: clients){
            if(c.getUsername().equals(username)&&c.getPassword().equals(password)){
                return c;
            }
        }
        return null;
    }

    public ArrayList<Client> getAllClients(){
        ArrayList<Client> clients = new ArrayList<>();
        try{

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT id, name, surname, username, password FROM clients");

            ResultSet resultSet = statement.executeQuery();


            while (resultSet.next()){

                clients.add(new Client(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getString("surname"),
                        resultSet.getString("username"),
                        resultSet.getString("password")
                ));
            }
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        return clients;
    }
    public Wallet createWallet(Wallet wallet){

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO wallets (name,cash)" +
                    "VALUES(?,?)");

            statement.setString(1,wallet.getName());
            statement.setDouble(2,wallet.getCash());
            statement.executeUpdate();
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        ArrayList<Wallet> wallets = getAllWallets();
        for(Wallet w: wallets){
            wallet = w;
        }
        return wallet;
    }

    public ArrayList<Wallet> getAllWallets(){
        ArrayList<Wallet> wallets = new ArrayList<>();
        try{

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT id, name, cash FROM wallets");

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()){

                wallets.add(new Wallet(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("cash")
                ));
            }statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        return wallets;
    }

    public Wallet getWalletByClientId(Long id){
        Wallet wallet = null;
        try{

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT id, name, cash FROM wallets WHERE client_id="+id + "");

            ResultSet resultSet = statement.executeQuery();


            while (resultSet.next()){

                wallet = new Wallet(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("cash")

                );
            }
            statement.close();


        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public void addWallet(Wallet wallet, Client client){
        Wallet newWallet = createWallet(wallet);
        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO clients_wallets (client_id,wallet_id)" +
                    "VALUES(?,?)");

            statement.setLong(1,client.getId());
            statement.setLong(2,newWallet.getId());
            statement.executeUpdate();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public void CheckForOperations(User user, Check check){
        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO operation_checks (client_id,check_id)" +
                    "VALUES(?,?)");

            statement.setLong(1,user.getId());
            statement.setLong(2,check.getId());
            statement.executeUpdate();
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }




}
