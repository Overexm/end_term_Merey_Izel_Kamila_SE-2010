package com.company.end;

public class Wallet //the user class
{

    private Long id;
    private String name;
    private double cash;

    public Wallet(Long id, String name, double cash) {
        this.id = id;
        this.name = name;
        this.cash = cash;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCash() {
        return cash;
    }

    public void setCash(double cash) {
        this.cash = cash;
    }
}


