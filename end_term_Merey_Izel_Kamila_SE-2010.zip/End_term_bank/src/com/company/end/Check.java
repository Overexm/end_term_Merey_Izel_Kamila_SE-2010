package com.company.end;
import java.sql.Date;

    public class Check  //this is check class
    {
        private Long id;
        private Wallet wallet;
        private Date date;
        private Client client;
        private String text;

        public Check(Long id, Wallet wallet, Date date, Client client,String text) {
            this.id = id;
            this.wallet = wallet;
            this.date = date;
            this.client = client;
            this.text = text;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public Wallet getWallet() {
            return wallet;
        }

        public void setWallet(Wallet wallet) {
            this.wallet = wallet;
        }

        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        }

        public Client getClient() {
            return client;
        }

        public void setClient(Client client) {
            this.client = client;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }


