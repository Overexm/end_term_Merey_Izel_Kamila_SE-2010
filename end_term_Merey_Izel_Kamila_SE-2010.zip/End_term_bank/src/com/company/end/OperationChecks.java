package com.company.end;

public class OperationChecks //operation check class
         {
    private Long id;
    private Long client_id;
    private Long check_id;

    public OperationChecks(Long id, Long client_id, Long check_id) {
        this.id = id;
        this.client_id = client_id;
        this.check_id = check_id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClient_id() {
        return client_id;
    }

    public void setClient_id(Long client_id) {
        this.client_id = client_id;
    }

    public Long getCheck_id() {
        return check_id;
    }

    public void setCheck_id(Long check_id) {
        this.check_id = check_id;
    }

}
