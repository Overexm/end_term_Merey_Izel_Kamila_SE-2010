package com.company.end;

public interface Service {//interface
    void addMoney();
    void withdrawCash();

}
