package com.company.end;
import java.util.ArrayList;
public class Client extends User// the client class
{
    private ArrayList<Wallet> myWallets = new ArrayList<>();

    public Client(Long id, String name, String surname, String username, String password) {
        super(id, name, surname, username, password);

    }


    public ArrayList<Wallet> getMyWallets() {
        return myWallets;
    }

    public void setMyWallets(ArrayList<Wallet> myWallets) {
        this.myWallets = myWallets;
    }
}

